# follow the instructions in README.md to obtain Twitter API credentials
consumer_key = ''
consumer_secret = ''
access_token = ''
access_token_secret = ''